﻿Đề Tài Môn Công Nghệ Phần Mềm: Quản Lý Điện Thoại

Giới thiệu về đề tài:

Hướng dẫn cách sử dụng:

--Mở hoặc download Visual Studio Bản 2022(nếu chưa download).

Link download:https://visualstudio.microsoft.com/vs/

Hướng dẫn người chưa download:

--Sau khi ấn vào link sẽ hiện ra trang chủ visual Studio 2022 IDE.

--Khi đưa chuột vào phần download sẽ hiện ra 3 phiên bản: Community 2022, Professional 2022 và cuối cùng là Enterprise 2022

--Chọn phiên bản:Community 2022.

--Sau khi download về thì sẽ hiện bản Visual Code Installer ấn vào Modify.

--Chọn Desktop & Mobile: Chọn.Net desktop development.

--Đợi nó download lần nữa thì có thể sử dụng Visual Studio 2022.

\====================================================================

Bước 1:

-- Bật Visual Studio 2022

--Mở file QuanLyDienThoai.sln

--trong file sẽ có phần Database có đề là quanLyDienThoai.sql

--Đồng thơi khởi động Microsoft SQL Server Management Studio.

--Tại cửa sổ Connect to Server: Trong mục Server name -> Chọn Browse for more..

-- Tại cửa sổ Browse for Servers: Chọn Database Engine -> Chọn tên server của SQL Server

-- Tại mục Authentication chọn Windows Authentication.

--Copy toàn bộ nội dung của quanLyDienThoai.sql vào của sổ New Query vừa tạo và Execute từng dòng lệnh.

\--------------------------------------------------------------------

Bước 2:

-- Sau khi mở QuanLyDienThoai.sln

-- Ấn vào App.config ở Data Source đổi tên Server name của máy chạy bài

--Ví dụ: connectionString="Data Source= TÊN CỦA SERVER NAME;Initial Catalog=quanlydienthoai;Integrated Security=True"

-- Sau khi chạy from đăng nhập sẽ hiện lên và nhập Tài Khoản,Mật Khẩu.

--gồm 2 tài khoản:

Tài Khoản:admin, Mật Khẩu:789456

Tài Khoản:thekhai ,Mật Khẩu:220797

-- Hiện lên thông báo đăng nhập thành công là được, sau khi đăng nhập vào 1 bảng khác là Quản Lý Điện Thoại.

+Thêm: Đưa chuột vào dòng bất kì trong DataGridView, nó sẽ làm mất dòng đã ấn Thêm đồng nghĩa nó đã Lưu dòng đó.	

+Sửa: Đưa chuột vào dòng còn đây đủ thông tin trong DataGridView rồi nhấn nút Sửa, nó sẽ hiện thông báo sửa thành

công những dòng mà khi ấn nút thêm đã làm mất.

+Xóa: Đưa chuột vào dòng bất kì trong DataGridView rồi nhấn Xóa, nó sẽ hiện thông báo xóa thành công vào dòng đó sẽ biến mất.

+Đóng: Đóng chương trình chạy.





