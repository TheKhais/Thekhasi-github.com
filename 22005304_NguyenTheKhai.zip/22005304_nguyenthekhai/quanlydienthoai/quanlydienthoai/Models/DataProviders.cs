﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data; //Dùng cho ConnectionState
using System.Data.SqlClient;
using System.Configuration;// Dùng cho ConfigurationManager

namespace quanlydienthoai.Models
{
    internal class DataProviders
    {
        public SqlConnection conn;

        public bool Connect()
        {
            string connectionStr = ConfigurationManager.ConnectionStrings["ConnectStr"].ConnectionString.ToString();

            conn = new SqlConnection(connectionStr);
            if ((conn.State == ConnectionState.Closed) || (conn.State == ConnectionState.Broken))
            {
                conn.Open();
                return true;
            }
            else
            {
                return false;
            }
        }
        public void DisConnect()
        {
            conn.Close();
            conn.Dispose();
        }
    }
}