﻿create database quanlydienthoai
go
use quanlydienthoai
go

CREATE TABLE NGUOIDUNG(
 MaND CHAR(2) NOT NULL PRIMARY KEY, 
 TenND nvarchar(40)
)


CREATE TABLE DIENTHOAI
(
    MaDT CHAR(4) NOT NULL PRIMARY KEY,
    TenDT nvarchar(150) NOT NULL,
    DVT nvarchar(10),
	NamSX CHAR(4),
	TriGia money,
	MaND CHAR(2), 
	Constraint fk_ND FOREIGN Key(MaND)references NGUOIDUNG(MaND)
)
--- Tạo cấu trúc bảng Users
--- ID tự động tăng, giá trị bắt đầu =1 và bước nhảy là 1 (identity(1,1))
CREATE TABLE Users(
 ID int identity(1,1) primary key,
 TenTK nvarchar(25),
 MatKhau nvarchar(25),
 MoTa nvarchar(100)
)
-- Nhập dữ liệu cho các bảng của CSDL QuanLyDienThoai

insert into NGUOIDUNG values('KD',N'Kinh doanh')
insert into NGUOIDUNG values('KT',N'Kế toán')
insert into NGUOIDUNG values('NS',N'Nhân sự')
insert into NGUOIDUNG values('IT',N'Công nghệ Thông tin')
insert into NGUOIDUNG values('MK',N'Marketing')
GO
-- Table DIENTHOAI
INSERT INTO DIENTHOAI VALUES('N1', N'Galaxy Note 20 Ultra', N'Hộp','2020',11285000,'NS')
INSERT INTO DIENTHOAI VALUES('N2', N'iPhone 12 Pro Max', N'Bộ','2020',1430000,'KT')
INSERT INTO DIENTHOAI VALUES('ML2', N'OPPO A95', N'Cái','2022',5530000,'KT')
INSERT INTO DIENTHOAI VALUES('ML3', N'Xiaomi 11T 5G', N'Cái','2022',10530000,'KT')
INSERT INTO DIENTHOAI VALUES('NL21', N'Xiaomi Redmi 10', N'Cái', '2021',4310000,'KD')
INSERT INTO DIENTHOAI VALUES('NL2', N'Realme 7 Pro', N'Cái', '2021',6590000,'MK')
INSERT INTO DIENTHOAI VALUES('LT1', N'Samsung Galaxy S22', N'Hộp','2022',14990000,'KD')

GO

/*Nhập dữ liệu cho Table Users*/
insert into Users(TenTK, MatKhau, MoTa) values('admin','789456',N'Quản trị viên')
insert into Users(TenTK, MatKhau, MoTa) values('thekhai','220797',N'Người dùng')
-- =============================================
CREATE PROCEDURE Usp_InsertDIENTHOAI
	-- Khai báo các tham số của stored procedure
	@PMaDT char(4), 
	@PTenDT nvarchar(100),
	@PDVT nvarchar(10),
	@PNamSX char(4),
	@PTriGia money,
	@PMaND CHAR(2)
AS
BEGIN
    -- Thêm một tài sản mới vào bảng DIENTHOAI
	INSERT INTO DIENTHOAI VALUES(@PMaDT,@PTenDT,@PDVT,@PNamSX,@PTriGia,@PMaND)
END
-- =============================================
CREATE PROCEDURE Usp_DeleteDIENTHOAI
	-- Khai báo tham số của stored procedure
	@PMaDT char(4) 
AS
BEGIN
    -- Xoá Khách hàng theo MaKh
	DELETE FROM DIENTHOAI WHERE MaDT=@PMaDT
END
-- =============================================
CREATE PROCEDURE Usp_UpdateDIENTHOAI
	-- Khai báo các tham số của stored procedure
	@PMaDT char(4), 
	@PTenDT nvarchar(100),
	@PDVT nvarchar(10),
	@PNamSX char(4),
	@PTriGia money,
	@PMaND CHAR(2)
AS
BEGIN
	UPDATE DIENTHOAI SET TenDT=@PTenDT, DVT=@PDVT, NamSX=@PNamSX, TriGia=@PTriGia, MaND=@PMaND WHERE MaDT=@PMaDT
END
-- =============================================
CREATE PROCEDURE Usp_SelectAllDIENTHOAI
	-- Khai báo các tham số của stored procedure
AS
BEGIN
	SELECT * FROM DIENTHOAI
END
