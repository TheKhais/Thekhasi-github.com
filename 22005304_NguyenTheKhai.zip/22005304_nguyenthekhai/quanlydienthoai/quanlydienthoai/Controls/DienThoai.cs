﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data; //Dùng cho kiểu dữ liệu DataTable, CommandType
using System.Data.SqlClient;
using quanlydienthoai.Models;// Khai báo để dùng Class DataProviders
using quanlydienthoai.Controls;

namespace quanlydienthoai.Controls
{
    internal class DienThoai
    {
        //Khai báo và khởi tạo đối tượng
        DataProviders providers = new DataProviders();
        public SqlConnection Conn()
        {
            return providers.conn;
        }
        //Viết hàm xử lý kết nối CSDL
        public Boolean Connect()
        {
            return providers.Connect();
        }//Kết thúc Connect()
        public void DisConnect()
        {
            providers.DisConnect();
        }//Kết thúc Connect()
         //========================================================================
         //Khai báo hàm chọn tất cả các Record trong bảng BANDOC bằng Stored Procedure
         //========================================================================

        public DataTable Usp_SelectAllDIENTHOAI()
        {
            // Khai báo biến kiểu dữ liệu DataTable
            DataTable tbl = new DataTable();
            if (Connect())
            {

                SqlCommand UspcmdSelect = new SqlCommand();

                UspcmdSelect.CommandText = "Usp_SelectAllDIENTHOAI";

                UspcmdSelect.CommandType = CommandType.StoredProcedure;

                UspcmdSelect.Connection = providers.conn;

                SqlDataAdapter da = new SqlDataAdapter(UspcmdSelect);

                da.Fill(tbl);
            }

            //Trả về kết quả
            return tbl;
        }//Kết thức hàm truy vấn dữ liệu Select
        public int Usp_DeleteDIENTHOAI(string MaDTValue)
        {
            int rec = 0;
            if (Connect())
            {
                SqlParameter paraMaDT = new SqlParameter("@PMaDT", MaDTValue);
                SqlCommand Uspcmd = new SqlCommand();
                Uspcmd.CommandText = "Usp_DeleteDIENTHOAI";
                Uspcmd.CommandType = CommandType.StoredProcedure;
                Uspcmd.Connection = providers.conn;
                Uspcmd.Parameters.Add(paraMaDT);

                rec = Uspcmd.ExecuteNonQuery();
            }
            else
            {
                rec = -1;
            }
            return rec;
        }
        public int Usp_InsertDIENTHOAI(string MaDTValue, string TenDTValue, string DVTValue, string NamSXValue, string TriGiaValue, System.Windows.Forms.ComboBox cob_MaND, string MaNDValue)
        {
            int rec = 0;

            //Kiểm tra kết nối DB và thực thi phương thức ExecuteNonQuery
            if (Connect())
            {
                //Khai báo các tham số cho Stored Procedure
                SqlParameter paraMaDT = new SqlParameter("@PMaDT",
                MaDTValue);
                SqlParameter paraTenDT = new SqlParameter("@PTenDT", TenDTValue);
                SqlParameter paraDVT = new SqlParameter("@PDVT",
                DVTValue);
                SqlParameter paraNamSX = new SqlParameter("@PNamSX",
                NamSXValue);
                SqlParameter paraTriGia = new SqlParameter("@PTriGia",
                TriGiaValue);
                SqlParameter paraMaND = new SqlParameter("@PMaND", MaNDValue);

                //khai báo và khởi tạo biến đối tượng sqlcommand
                SqlCommand Uspcmd = new SqlCommand();
                //Gán giá trị cho các thuộc tính của biến đối tượngsqlcommand
                Uspcmd.CommandText = "Usp_InsertDIENTHOAI";
                Uspcmd.CommandType = CommandType.StoredProcedure;
                Uspcmd.Connection = providers.conn;
                //Thêm các tham số cho biến đối tượng sqlcommand
                Uspcmd.Parameters.Add(paraMaDT);
                Uspcmd.Parameters.Add(paraTenDT);
                Uspcmd.Parameters.Add(paraDVT);
                Uspcmd.Parameters.Add(paraNamSX);
                Uspcmd.Parameters.Add(paraTriGia);
                Uspcmd.Parameters.Add(paraMaND);

                //Gọi thực thi phương thức ExecuteNonQuery()
                rec = Uspcmd.ExecuteNonQuery();
            }
            else
            {
                rec = -1;
            }
            return rec;
        }
    }
}
    