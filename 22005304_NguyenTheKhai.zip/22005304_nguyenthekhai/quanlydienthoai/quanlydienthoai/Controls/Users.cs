﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using quanlydienthoai.Models;
using System.Configuration;
using System.Data.SqlClient;

namespace quanlydienthoai.Controls
{
    internal class Users
    {
        DataProviders Db = new DataProviders();
        public int CheckUser(string User, string Pass)
        {
            Db.Connect();
            string strsql = "Select count(*) from Users where ((TenTK=@TaiKhoan) and(MatKhau = @MatKhauNguoiDung))";
            SqlCommand Cmd = new SqlCommand(strsql, Db.conn);
            //Tạo các Parameters cho câu lệnh SQL
            Cmd.Parameters.Add(new SqlParameter("@TaiKhoan", User));
            Cmd.Parameters.Add(new SqlParameter("@MatKhauNguoiDung", Pass));
            int kqsql = (int)Cmd.ExecuteScalar();
            return kqsql;
        }
    }
}