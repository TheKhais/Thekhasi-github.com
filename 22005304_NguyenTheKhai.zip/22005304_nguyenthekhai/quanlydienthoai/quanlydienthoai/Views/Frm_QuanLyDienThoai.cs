﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using quanlydienthoai.Controls;
using System.Configuration;
using System.Data.SqlClient;

namespace quanlydienthoai.Views
{
    public partial class Frm_QuanLyDienThoai : Form
    {
        private bool VarSave;
        public Frm_QuanLyDienThoai()
        {
            InitializeComponent();
        }

        private void Frm_QuanLyDienThoai_Load(object sender, EventArgs e)
        {
            DataDIENTHOAI();
        }
        void DataDIENTHOAI()
        {
            DataTable DataDIENTHOAI;
            DienThoai dienthoai = new DienThoai();
            if (dienthoai.Connect())
            {
                DataDIENTHOAI = dienthoai.Usp_SelectAllDIENTHOAI();
                Dgv_QuanLyDienThoai.DataSource = DataDIENTHOAI;

                BindingDataDIENTHOAI();
            }
            else
                MessageBox.Show("Lỗi không kết nối được Database!!");
        }
        void BindingDataDIENTHOAI()
        {
            Txt_MaDT.DataBindings.Clear();
            Txt_TenDT.DataBindings.Clear();
            Txt_DVT.DataBindings.Clear();
            Txt_NamSX.DataBindings.Clear();
            Txt_TriGia.DataBindings.Clear();
            cob_MaND.DataBindings.Clear();

            //DataBindings dữ liệu lên các TextBox
            Txt_MaDT.DataBindings.Add("Text", Dgv_QuanLyDienThoai.DataSource,
            "MaDT");
            Txt_TenDT.DataBindings.Add("Text",
            Dgv_QuanLyDienThoai.DataSource, "TenDT");
            Txt_DVT.DataBindings.Add("Text", Dgv_QuanLyDienThoai.DataSource,
            "DVT");
            Txt_NamSX.DataBindings.Add("Text", Dgv_QuanLyDienThoai.DataSource,
            "NamSX");
            Txt_TriGia.DataBindings.Add("Text",
            Dgv_QuanLyDienThoai.DataSource, "TriGia");
            cob_MaND.DataBindings.Add("Text", Dgv_QuanLyDienThoai.DataSource, "MaND");
        }

        private void Btn_Them_Click(object sender, EventArgs e)
        {
            ResetAll_Data();
            //Người dùng đã nhấn Btn_Them
            VarSave = true;
        }//Kết thúc Btn_Them_Click
        void ResetAll_Data()
        {
            Txt_MaDT.Clear();
            Txt_TenDT.ResetText();
            Txt_DVT.Clear();
            Txt_NamSX.Text = "";
            Txt_TriGia.ResetText();
            cob_MaND.Text = "";

        } // Kết thúc ResetAll_Data()

        private void Btn_Sua_Click(object sender, EventArgs e)
        {
            if (Txt_MaDT.Text == "")
            {
                MessageBox.Show("Vui lòng nhập mã điện thoại cần sửa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Txt_MaDT.Focus();
            }
            else if (KTThongTin())
            {
                try
                {
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectStr"].ConnectionString;
                    SqlCommand cmd = new SqlCommand();

                    cmd.CommandText = "Usp_UpdateDIENTHOAI";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@PMaDT ", SqlDbType.Char).Value = Txt_MaDT.Text;
                    cmd.Parameters.Add("@PTenDT ", SqlDbType.NVarChar).Value = Txt_TenDT.Text;
                    cmd.Parameters.Add("@PDVT ", SqlDbType.NVarChar).Value = Txt_DVT.Text;
                    cmd.Parameters.Add("@PNamSX ", SqlDbType.NVarChar).Value = Txt_NamSX.Text;
                    cmd.Parameters.Add("@PTriGia ", SqlDbType.NVarChar).Value = Txt_TriGia.Text;
                    cmd.Parameters.Add("@PMaND", SqlDbType.Char).Value = cob_MaND.Text;

                    cmd.Connection = conn;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    DataDIENTHOAI();
                    MessageBox.Show("Đã sửa tài sản thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Btn_Xoa_Click(object sender, EventArgs e)
        {
            if (Txt_MaDT.Text == "")
            {
                MessageBox.Show("Vui lòng nhập mã điện thoại cần xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Txt_MaDT.Focus();
            }
            else if (KTThongTin())
            {
                try
                {
                    SqlConnection conn = new SqlConnection();
                    conn.ConnectionString = ConfigurationManager.ConnectionStrings["ConnectStr"].ConnectionString;
                    SqlCommand cmd = new SqlCommand();

                    cmd.CommandText = "Usp_DeleteDIENTHOAI";
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@PMaDT", SqlDbType.Char).Value = Txt_MaDT.Text;

                    cmd.Connection = conn;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    DataDIENTHOAI();
                    MessageBox.Show("Đã xóa điện thoại thành công", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
        public bool KTThongTin()
        {
            if (Txt_TenDT.Text == "")
            {
                MessageBox.Show("Vui lòng nhập tên điện thoại", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Txt_TenDT.Focus();
                return false;
            }
            if (Txt_DVT.Text == "")
            {
                MessageBox.Show("Vui lòng nhập đơn vị tính", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Txt_DVT.Focus();
                return false;
            }
            if (Txt_NamSX.Text == "")
            {
                MessageBox.Show("Vui lòng nhập năm sản xuất", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Txt_NamSX.Focus();
                return false;
            }
            if (Txt_TriGia.Text == "")
            {
                MessageBox.Show("Vui lòng nhập trị giá", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Txt_TriGia.Focus();
                return false;
            }
            if (cob_MaND.Text == "")
            {
                MessageBox.Show("Vui lòng nhập mã người dùng", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cob_MaND.Focus();
                return false;
            }
            return true;
        }


        private void Btn_Dong_Click(object sender, EventArgs e)
        {
            DialogResult Kq = MessageBox.Show("Bạn có chắc chắn đóng cửa sổ không ? ", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Kq == DialogResult.Yes)
            {
                this.Close();
            }
        }//Kết thúc Btn_Dong_Click
    }
}