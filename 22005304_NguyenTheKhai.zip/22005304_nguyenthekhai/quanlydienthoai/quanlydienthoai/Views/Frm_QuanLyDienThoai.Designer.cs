﻿namespace quanlydienthoai.Views
{
    partial class Frm_QuanLyDienThoai
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Lbl_MaDT = new System.Windows.Forms.Label();
            this.Lbl_TenDT = new System.Windows.Forms.Label();
            this.Lbl_DVT = new System.Windows.Forms.Label();
            this.Txt_MaDT = new System.Windows.Forms.TextBox();
            this.Txt_TenDT = new System.Windows.Forms.TextBox();
            this.Txt_DVT = new System.Windows.Forms.TextBox();
            this.Lbl_NSX = new System.Windows.Forms.Label();
            this.Lbl_TriGia = new System.Windows.Forms.Label();
            this.Lbl_MaND = new System.Windows.Forms.Label();
            this.Txt_NamSX = new System.Windows.Forms.TextBox();
            this.Txt_TriGia = new System.Windows.Forms.TextBox();
            this.cob_MaND = new System.Windows.Forms.ComboBox();
            this.Dgv_QuanLyDienThoai = new System.Windows.Forms.DataGridView();
            this.Btn_Xoa = new System.Windows.Forms.Button();
            this.Btn_Dong = new System.Windows.Forms.Button();
            this.Btn_Sua = new System.Windows.Forms.Button();
            this.Btn_Them = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_QuanLyDienThoai)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(153, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(335, 33);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUẢN LÝ ĐIỆN THOẠI";
            // 
            // Lbl_MaDT
            // 
            this.Lbl_MaDT.AutoSize = true;
            this.Lbl_MaDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_MaDT.Location = new System.Drawing.Point(67, 84);
            this.Lbl_MaDT.Name = "Lbl_MaDT";
            this.Lbl_MaDT.Size = new System.Drawing.Size(60, 20);
            this.Lbl_MaDT.TabIndex = 1;
            this.Lbl_MaDT.Text = "Mã ĐT:";
            // 
            // Lbl_TenDT
            // 
            this.Lbl_TenDT.AutoSize = true;
            this.Lbl_TenDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_TenDT.Location = new System.Drawing.Point(67, 122);
            this.Lbl_TenDT.Name = "Lbl_TenDT";
            this.Lbl_TenDT.Size = new System.Drawing.Size(65, 20);
            this.Lbl_TenDT.TabIndex = 2;
            this.Lbl_TenDT.Text = "Tên ĐT:";
            // 
            // Lbl_DVT
            // 
            this.Lbl_DVT.AutoSize = true;
            this.Lbl_DVT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_DVT.Location = new System.Drawing.Point(67, 163);
            this.Lbl_DVT.Name = "Lbl_DVT";
            this.Lbl_DVT.Size = new System.Drawing.Size(95, 20);
            this.Lbl_DVT.TabIndex = 3;
            this.Lbl_DVT.Text = "Đơn Vị Tính:";
            // 
            // Txt_MaDT
            // 
            this.Txt_MaDT.Location = new System.Drawing.Point(133, 86);
            this.Txt_MaDT.Name = "Txt_MaDT";
            this.Txt_MaDT.Size = new System.Drawing.Size(163, 20);
            this.Txt_MaDT.TabIndex = 4;
            // 
            // Txt_TenDT
            // 
            this.Txt_TenDT.Location = new System.Drawing.Point(133, 122);
            this.Txt_TenDT.Name = "Txt_TenDT";
            this.Txt_TenDT.Size = new System.Drawing.Size(163, 20);
            this.Txt_TenDT.TabIndex = 4;
            // 
            // Txt_DVT
            // 
            this.Txt_DVT.Location = new System.Drawing.Point(159, 163);
            this.Txt_DVT.Name = "Txt_DVT";
            this.Txt_DVT.Size = new System.Drawing.Size(137, 20);
            this.Txt_DVT.TabIndex = 4;
            // 
            // Lbl_NSX
            // 
            this.Lbl_NSX.AutoSize = true;
            this.Lbl_NSX.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_NSX.Location = new System.Drawing.Point(330, 84);
            this.Lbl_NSX.Name = "Lbl_NSX";
            this.Lbl_NSX.Size = new System.Drawing.Size(117, 20);
            this.Lbl_NSX.TabIndex = 5;
            this.Lbl_NSX.Text = "Năm Sản Xuất:";
            // 
            // Lbl_TriGia
            // 
            this.Lbl_TriGia.AutoSize = true;
            this.Lbl_TriGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_TriGia.Location = new System.Drawing.Point(330, 120);
            this.Lbl_TriGia.Name = "Lbl_TriGia";
            this.Lbl_TriGia.Size = new System.Drawing.Size(59, 20);
            this.Lbl_TriGia.TabIndex = 6;
            this.Lbl_TriGia.Text = "Trị Giá:";
            // 
            // Lbl_MaND
            // 
            this.Lbl_MaND.AutoSize = true;
            this.Lbl_MaND.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_MaND.Location = new System.Drawing.Point(330, 161);
            this.Lbl_MaND.Name = "Lbl_MaND";
            this.Lbl_MaND.Size = new System.Drawing.Size(62, 20);
            this.Lbl_MaND.TabIndex = 7;
            this.Lbl_MaND.Text = "Ma ND:";
            // 
            // Txt_NamSX
            // 
            this.Txt_NamSX.Location = new System.Drawing.Point(453, 84);
            this.Txt_NamSX.Name = "Txt_NamSX";
            this.Txt_NamSX.Size = new System.Drawing.Size(113, 20);
            this.Txt_NamSX.TabIndex = 8;
            // 
            // Txt_TriGia
            // 
            this.Txt_TriGia.Location = new System.Drawing.Point(395, 122);
            this.Txt_TriGia.Name = "Txt_TriGia";
            this.Txt_TriGia.Size = new System.Drawing.Size(171, 20);
            this.Txt_TriGia.TabIndex = 8;
            // 
            // cob_MaND
            // 
            this.cob_MaND.FormattingEnabled = true;
            this.cob_MaND.Location = new System.Drawing.Point(398, 162);
            this.cob_MaND.Name = "cob_MaND";
            this.cob_MaND.Size = new System.Drawing.Size(168, 21);
            this.cob_MaND.TabIndex = 9;
            // 
            // Dgv_QuanLyDienThoai
            // 
            this.Dgv_QuanLyDienThoai.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Dgv_QuanLyDienThoai.Location = new System.Drawing.Point(71, 205);
            this.Dgv_QuanLyDienThoai.Name = "Dgv_QuanLyDienThoai";
            this.Dgv_QuanLyDienThoai.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.Dgv_QuanLyDienThoai.Size = new System.Drawing.Size(495, 150);
            this.Dgv_QuanLyDienThoai.TabIndex = 10;
            // 
            // Btn_Xoa
            // 
            this.Btn_Xoa.Location = new System.Drawing.Point(318, 361);
            this.Btn_Xoa.Name = "Btn_Xoa";
            this.Btn_Xoa.Size = new System.Drawing.Size(113, 38);
            this.Btn_Xoa.TabIndex = 11;
            this.Btn_Xoa.Text = "Xóa";
            this.Btn_Xoa.UseVisualStyleBackColor = true;
            this.Btn_Xoa.Click += new System.EventHandler(this.Btn_Xoa_Click);
            // 
            // Btn_Dong
            // 
            this.Btn_Dong.Location = new System.Drawing.Point(453, 361);
            this.Btn_Dong.Name = "Btn_Dong";
            this.Btn_Dong.Size = new System.Drawing.Size(113, 38);
            this.Btn_Dong.TabIndex = 11;
            this.Btn_Dong.Text = "Đóng";
            this.Btn_Dong.UseVisualStyleBackColor = true;
            this.Btn_Dong.Click += new System.EventHandler(this.Btn_Dong_Click);
            // 
            // Btn_Sua
            // 
            this.Btn_Sua.Location = new System.Drawing.Point(190, 361);
            this.Btn_Sua.Name = "Btn_Sua";
            this.Btn_Sua.Size = new System.Drawing.Size(113, 38);
            this.Btn_Sua.TabIndex = 11;
            this.Btn_Sua.Text = "Sửa";
            this.Btn_Sua.UseVisualStyleBackColor = true;
            this.Btn_Sua.Click += new System.EventHandler(this.Btn_Sua_Click);
            // 
            // Btn_Them
            // 
            this.Btn_Them.Location = new System.Drawing.Point(71, 361);
            this.Btn_Them.Name = "Btn_Them";
            this.Btn_Them.Size = new System.Drawing.Size(113, 38);
            this.Btn_Them.TabIndex = 11;
            this.Btn_Them.Text = "Thêm";
            this.Btn_Them.UseVisualStyleBackColor = true;
            this.Btn_Them.Click += new System.EventHandler(this.Btn_Them_Click);
            // 
            // Frm_QuanLyDienThoai
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(635, 411);
            this.Controls.Add(this.Btn_Dong);
            this.Controls.Add(this.Btn_Them);
            this.Controls.Add(this.Btn_Sua);
            this.Controls.Add(this.Btn_Xoa);
            this.Controls.Add(this.Dgv_QuanLyDienThoai);
            this.Controls.Add(this.cob_MaND);
            this.Controls.Add(this.Txt_TriGia);
            this.Controls.Add(this.Txt_NamSX);
            this.Controls.Add(this.Lbl_MaND);
            this.Controls.Add(this.Lbl_TriGia);
            this.Controls.Add(this.Lbl_NSX);
            this.Controls.Add(this.Txt_DVT);
            this.Controls.Add(this.Txt_TenDT);
            this.Controls.Add(this.Txt_MaDT);
            this.Controls.Add(this.Lbl_DVT);
            this.Controls.Add(this.Lbl_TenDT);
            this.Controls.Add(this.Lbl_MaDT);
            this.Controls.Add(this.label1);
            this.Name = "Frm_QuanLyDienThoai";
            this.Text = "Frm_QuanLyDienThoai";
            this.Load += new System.EventHandler(this.Frm_QuanLyDienThoai_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Dgv_QuanLyDienThoai)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Lbl_MaDT;
        private System.Windows.Forms.Label Lbl_TenDT;
        private System.Windows.Forms.Label Lbl_DVT;
        private System.Windows.Forms.TextBox Txt_MaDT;
        private System.Windows.Forms.TextBox Txt_TenDT;
        private System.Windows.Forms.TextBox Txt_DVT;
        private System.Windows.Forms.Label Lbl_NSX;
        private System.Windows.Forms.Label Lbl_TriGia;
        private System.Windows.Forms.Label Lbl_MaND;
        private System.Windows.Forms.TextBox Txt_NamSX;
        private System.Windows.Forms.TextBox Txt_TriGia;
        private System.Windows.Forms.ComboBox cob_MaND;
        private System.Windows.Forms.DataGridView Dgv_QuanLyDienThoai;
        private System.Windows.Forms.Button Btn_Xoa;
        private System.Windows.Forms.Button Btn_Dong;
        private System.Windows.Forms.Button Btn_Sua;
        private System.Windows.Forms.Button Btn_Them;
    }
}