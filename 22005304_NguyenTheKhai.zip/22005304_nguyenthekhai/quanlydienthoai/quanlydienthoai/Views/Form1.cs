﻿using quanlydienthoai.Controls;
using quanlydienthoai.Views;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace quanlydienthoai
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void Btn_DangNhap_Click(object sender, EventArgs e)
        {
            Users User = new Users();
            int kq = User.CheckUser(Txt_TenTaiKhoan.Text, Txt_MatKhau.Text);
            if (kq == 1)
            {
                MessageBox.Show("Chúc mừng bạn đã Đăng nhập thành công", "Thông báo");
                Form frm = new Frm_QuanLyDienThoai();
                frm.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Không đúng tên tài khoản hoặc mật khẩu !!!", "Thông báo");
                this.Txt_TenTaiKhoan.Focus();
            }
        }

        private void Btn_Huy_Click(object sender, EventArgs e)
        {
            DialogResult Kq = MessageBox.Show("Bạn có chắc chắn thoát khỏi ứng dụng không ? ", "Thông báo!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (Kq == DialogResult.Yes)
            {
                Application.Exit();
            }
        }//Kết thúc Btn_Huy_Click
    }
}